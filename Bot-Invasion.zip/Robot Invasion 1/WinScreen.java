import greenfoot.*;

public class WinScreen extends Actor {
    // FONT SETTINGS
    private static final String FONT_NAME = "Courier New";
    private static final int FONT_SIZE = 60;
    
    // COLOR SETTINGS
    private static final Color TEXT_COLOR = new Color(220, 220, 220);      // Putih abu-abu
    private static final Color OUTLINE_COLOR = new Color(0, 0, 0);         // Hitam
    
    public WinScreen() {
        createWinMessage();
    }
    
    private void createWinMessage() {
        // ✅ TRANSPARAN PENUH (NO BLACK BOX)
        GreenfootImage img = new GreenfootImage(400, 200);
        img.setColor(new Color(0, 0, 0, 0)); // Transparan
        img.fill();
        
        String text = "YOU WIN!";
        
        // Set font
        img.setFont(new Font(FONT_NAME, true, false, FONT_SIZE));
        
        // Draw outline (8 directions)
        img.setColor(OUTLINE_COLOR);
        for (int dx = -3; dx <= 3; dx++) { // Outline lebih tebal
            for (int dy = -3; dy <= 3; dy++) {
                if (dx != 0 || dy != 0) {
                    img.drawString(text, 60 + dx, 120 + dy);
                }
            }
        }
        
        // Draw main text (putih abu-abu)
        img.setColor(TEXT_COLOR);
        img.drawString(text, 60, 120);
        
        setImage(img);
    }
}