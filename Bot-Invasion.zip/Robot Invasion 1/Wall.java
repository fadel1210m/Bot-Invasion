import greenfoot.*;

public class Wall extends Actor {
    public Wall() {
        // Buat image transparan penuh (invisible)
        GreenfootImage img = new GreenfootImage(20, 20);
        img.setTransparency(0); // ✅ TRANSPARAN PENUH = INVISIBLE
        setImage(img);
    }
    
    // Wall adalah objek statis, tidak perlu act()
}