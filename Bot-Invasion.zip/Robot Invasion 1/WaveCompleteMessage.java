import greenfoot.*;

public class WaveCompleteMessage extends Actor {
    // FONT SETTINGS
    private static final String FONT_NAME = "Courier New";
    private static final int FONT_SIZE_LARGE = 40;
    private static final int FONT_SIZE_SMALL = 20;
    
    // COLOR SETTINGS
    private static final Color TEXT_COLOR = new Color(220, 220, 220);      // Putih abu-abu
    private static final Color OUTLINE_COLOR = new Color(0, 0, 0);         // Hitam
    
    public WaveCompleteMessage(int wave) {
        createMessage(wave);
    }
    
    private void createMessage(int wave) {
        // ✅ TRANSPARAN PENUH (NO BLACK BOX)
        GreenfootImage img = new GreenfootImage(400, 120);
        img.setColor(new Color(0, 0, 0, 0)); // Transparan
        img.fill();
        
        if (wave < 3) {
            // Wave 1 atau 2 selesai
            String text1 = "GELOMBANG " + wave;
            String text2 = "SELESAI!";
            
            // Draw text1 dengan outline
            drawTextWithOutline(img, text1, FONT_SIZE_LARGE, 60, 50);
            
            // Draw text2 dengan outline
            drawTextWithOutline(img, text2, FONT_SIZE_LARGE, 100, 90);
            
        } else {
            // Boss fight start
            String text1 = "BOSS FIGHT!";
            String text2 = "Hati-hati dengan proyektilnya!";
            
            // Draw text1 dengan outline
            drawTextWithOutline(img, text1, FONT_SIZE_LARGE, 80, 50);
            
            // Draw text2 dengan outline (smaller)
            drawTextWithOutline(img, text2, FONT_SIZE_SMALL, 60, 90);
        }
        
        setImage(img);
    }
    
    // ✅ HELPER METHOD: Draw text dengan outline
    private void drawTextWithOutline(GreenfootImage img, String text, int fontSize, int x, int y) {
        img.setFont(new Font(FONT_NAME, true, false, fontSize));
        
        // Draw outline (8 directions)
        img.setColor(OUTLINE_COLOR);
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                if (dx != 0 || dy != 0) {
                    img.drawString(text, x + dx, y + dy);
                }
            }
        }
        
        // Draw main text
        img.setColor(TEXT_COLOR);
        img.drawString(text, x, y);
    }
}