import greenfoot.*;

public class EnemyType2 extends Enemy {
    // SISTEM ANIMASI SPRITE
    private GreenfootImage[] walkFrames;
    private GreenfootImage[] walkFramesLeft;
    
    private int currentFrame = 0;
    private int animationCounter = 0;
    private static final int WALK_ANIMATION_SPEED = 6;
    
    // UKURAN VISUAL
    private static final int VISUAL_WIDTH = 60;
    private static final int VISUAL_HEIGHT = 60;
    
    // ARAH MENGHADAP
    private boolean facingRight = true;
    
    // SHADOW SYSTEM
    private EnemyShadow shadow;
    private static final int SHADOW_OFFSET_Y = 26;

    public EnemyType2() {
        this.speed = 3;
        
        loadWalkAnimation();
        
        if (walkFrames != null && walkFrames.length > 0) {
            setImage(walkFrames[0]);
        } else {
            createFallbackVisual();
        }
        
        System.out.println("EnemyType2 created with 8-directional movement");
    }
    
    @Override
    public void addedToWorld(World world) {
        shadow = new EnemyShadow();
        world.addObject(shadow, getX(), getY() + SHADOW_OFFSET_Y);
    }
    
    private void updateShadowPosition() {
        if (shadow != null && shadow.getWorld() != null) {
            shadow.setLocation(getX(), getY() + SHADOW_OFFSET_Y);
        }
    }
    
    // ✅ HAPUS @Override, BUAT METHOD BIASA untuk cleanup shadow
    private void removeShadow() {
        if (shadow != null && shadow.getWorld() != null) {
            getWorld().removeObject(shadow);
            shadow = null;
        }
    }
    
    // ✅ OVERRIDE safeRemove() dan TAMBAHKAN removeShadow()
    @Override
    public void safeRemove() {
        if (!isRemoved && getWorld() != null) {
            isRemoved = true;
            
            removeShadow(); // ✅ HAPUS SHADOW DULU
            
            World world = getWorld();
            if (world instanceof DungeonWorld) {
                ((DungeonWorld) world).enemyKilled();
            }
            
            world.removeObject(this);
        }
    }
    
    private void loadWalkAnimation() {
        walkFrames = new GreenfootImage[4];
        walkFramesLeft = new GreenfootImage[4];
        
        for (int i = 0; i < 4; i++) {
            try {
                walkFrames[i] = new GreenfootImage("enemy2_walk_" + (i + 1) + ".png");
                walkFrames[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
                
                walkFramesLeft[i] = new GreenfootImage("enemy2_walk_" + (i + 1) + ".png");
                walkFramesLeft[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
                walkFramesLeft[i].mirrorHorizontally();
            } catch (IllegalArgumentException e) {
                System.out.println("Warning: enemy2_walk_" + (i + 1) + ".png not found!");
                walkFrames[i] = createFallbackFrame();
                walkFramesLeft[i] = createFallbackFrame();
            }
        }
    }
    
    private GreenfootImage createFallbackFrame() {
        GreenfootImage img = new GreenfootImage(VISUAL_WIDTH, VISUAL_HEIGHT);
        img.setColor(Color.RED);
        img.fillOval(0, 0, VISUAL_WIDTH, VISUAL_HEIGHT);
        return img;
    }
    
    private void createFallbackVisual() {
        GreenfootImage img = new GreenfootImage(25, 25);
        img.setColor(Color.RED);
        img.fillOval(0, 0, 25, 25);
        setImage(img);
    }
    
    @Override
    public void act() {
        if (isRemoved || getWorld() == null) return;
        
        updateAnimation();
        moveTowardsPlayer8Direction();
        checkWallCollision();
        attackPlayer();
        updateShadowPosition();
        
        if (attackCooldown > 0) attackCooldown--;
    }
    
    private void moveTowardsPlayer8Direction() {
        if (getWorld() == null) return;
        
        Actor player = getWorld().getObjects(Player.class).isEmpty() ? null : getWorld().getObjects(Player.class).get(0);
        
        if (player != null) {
            int dx = player.getX() - getX();
            int dy = player.getY() - getY();
            
            double distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance > 0) {
                int moveX = 0;
                int moveY = 0;
                
                if (Math.abs(dx) > distance * 0.38) {
                    if (dx > 0) {
                        moveX = speed;
                        facingRight = true;
                    } else {
                        moveX = -speed;
                        facingRight = false;
                    }
                }
                
                if (Math.abs(dy) > distance * 0.38) {
                    if (dy > 0) {
                        moveY = speed;
                    } else {
                        moveY = -speed;
                    }
                }
                
                if (moveX != 0 && moveY != 0) {
                    moveX = (int)(moveX * 0.707);
                    moveY = (int)(moveY * 0.707);
                }
                
                int oldX = getX();
                int oldY = getY();
                
                setLocation(getX() + moveX, getY() + moveY);
                
                if (checkWallCollisionAdvanced()) {
                    setLocation(oldX, oldY);
                }
            }
        }
    }
    
    private boolean checkWallCollisionAdvanced() {
        if (getWorld() == null) return false;
        
        Wall wall = (Wall) getOneIntersectingObject(Wall.class);
        return wall != null;
    }
    
    private void updateAnimation() {
        animationCounter++;
        
        if (animationCounter >= WALK_ANIMATION_SPEED) {
            animationCounter = 0;
            currentFrame++;
            
            if (currentFrame >= 4) {
                currentFrame = 0;
            }
            
            if (walkFrames != null && walkFramesLeft != null && 
                currentFrame < walkFrames.length && 
                currentFrame < walkFramesLeft.length) {
                if (facingRight) {
                    setImage(walkFrames[currentFrame]);
                } else {
                    setImage(walkFramesLeft[currentFrame]);
                }
            }
        }
    }
}