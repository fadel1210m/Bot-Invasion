import greenfoot.*;

public class Boss extends Enemy {
    private int bossHealth = 15;
    private boolean isDying = false;
    private static final int BOSS_MELEE_RANGE = 25;
    private static final int BOSS_HITBOX_RADIUS = 50;
    
    // ATTACK CYCLE SYSTEM
    private boolean isAttacking = false;
    private boolean isIdleAfterAttack = false;
    
    // PROJECTILE SHOOTING
    private int burstCount = 0;
    private int burstMax = 16;
    private int burstDelay = 15;
    private int burstTimer = 0;
    private boolean isShooting = false;
    
    // GLITCH TELEPORT SYSTEM
    private boolean willTeleport = false;
    private boolean isGlitching = false;
    private int glitchTimer = 0;
    private static final int GLITCH_DURATION = 30;
    private int glitchIntensity = 0;
    private int newTeleportX = 0;
    private int newTeleportY = 0;
    
    // GLITCH VISUAL CACHE
    private GreenfootImage baseImageCache = null;
    
    // SISTEM ANIMASI SPRITE
    private GreenfootImage[] idleFrames;
    private GreenfootImage[] idleFramesLeft;
    private GreenfootImage[] attackFrames;
    private GreenfootImage[] attackFramesLeft;
    private GreenfootImage[] deathFrames;
    private GreenfootImage[] deathFramesLeft;
    private GreenfootImage[] hitFrames;
    private GreenfootImage[] hitFramesLeft;
    
    private int currentFrame = 0;
    private int animationCounter = 0;
    private static final int IDLE_ANIMATION_SPEED = 6;
    private static final int ATTACK_ANIMATION_SPEED = 4;
    private static final int DEATH_ANIMATION_SPEED = 8;
    private static final int HIT_ANIMATION_SPEED = 4;
    
    private String currentAnimation = "idle";
    private boolean animationFinished = true;
    private int animationLoopCount = 0;
    
    // FACING DIRECTION SYSTEM
    private boolean facingRight = true;
    
    // UKURAN VISUAL
    private static final int VISUAL_WIDTH = 250;
    private static final int VISUAL_HEIGHT = 250;
    
    // TELEPORT BOUNDARIES
    private static final int MIN_X = 200;
    private static final int MAX_X = 600;
    private static final int MIN_Y = 150;
    private static final int MAX_Y = 400;
    
    // SHADOW SYSTEM ✅ BARU
    private BossShadow shadow;
    private static final int SHADOW_OFFSET_Y = 115; // Jarak shadow dari boss

    public Boss() {
        speed = 0;
        loadAllAnimations();
        
        if (idleFrames != null && idleFrames.length > 0) {
            setImage(idleFrames[0]);
        } else {
            createFallbackVisual();
        }
    }
    
    // ========== SHADOW SYSTEM ✅ BARU ==========
    
    @Override
    public void addedToWorld(World world) {
        // Spawn shadow saat boss ditambahkan ke world
        shadow = new BossShadow();
        world.addObject(shadow, getX(), getY() + SHADOW_OFFSET_Y);
        System.out.println("✓ Boss shadow created");
    }
    
    private void updateShadowPosition() {
        // Update posisi shadow mengikuti boss
        if (shadow != null && shadow.getWorld() != null) {
            shadow.setLocation(getX(), getY() + SHADOW_OFFSET_Y);
        }
    }
    
    private void removeShadow() {
        // Hapus shadow saat boss removed
        if (shadow != null && shadow.getWorld() != null) {
            getWorld().removeObject(shadow);
            shadow = null;
        }
    }
    
    // ========== ANIMATION LOADING ==========
    
    private void loadAllAnimations() {
        // IDLE ANIMATION (4 frames) - RIGHT & LEFT
        idleFrames = new GreenfootImage[4];
        idleFramesLeft = new GreenfootImage[4];
        for (int i = 0; i < 4; i++) {
            try {
                // RIGHT VERSION
                idleFrames[i] = new GreenfootImage("boss_idle_" + (i + 1) + ".png");
                idleFrames[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
                
                // LEFT VERSION (MIRROR)
                idleFramesLeft[i] = new GreenfootImage("boss_idle_" + (i + 1) + ".png");
                idleFramesLeft[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
                idleFramesLeft[i].mirrorHorizontally();
            } catch (IllegalArgumentException e) {
                idleFrames[i] = createFallbackFrame("IDLE");
                idleFramesLeft[i] = createFallbackFrame("IDLE");
            }
        }
        
        // ATTACK ANIMATION (8 frames) - RIGHT & LEFT
        attackFrames = new GreenfootImage[8];
        attackFramesLeft = new GreenfootImage[8];
        for (int i = 0; i < 8; i++) {
            try {
                // RIGHT VERSION
                attackFrames[i] = new GreenfootImage("boss_attack_" + (i + 1) + ".png");
                attackFrames[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
                
                // LEFT VERSION (MIRROR)
                attackFramesLeft[i] = new GreenfootImage("boss_attack_" + (i + 1) + ".png");
                attackFramesLeft[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
                attackFramesLeft[i].mirrorHorizontally();
            } catch (IllegalArgumentException e) {
                attackFrames[i] = createFallbackFrame("ATK");
                attackFramesLeft[i] = createFallbackFrame("ATK");
            }
        }
        
        // DEATH ANIMATION (6 frames) - RIGHT & LEFT
        deathFrames = new GreenfootImage[6];
        deathFramesLeft = new GreenfootImage[6];
        for (int i = 0; i < 6; i++) {
            try {
                // RIGHT VERSION
                deathFrames[i] = new GreenfootImage("boss_death_" + (i + 1) + ".png");
                deathFrames[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
                
                // LEFT VERSION (MIRROR)
                deathFramesLeft[i] = new GreenfootImage("boss_death_" + (i + 1) + ".png");
                deathFramesLeft[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
                deathFramesLeft[i].mirrorHorizontally();
            } catch (IllegalArgumentException e) {
                deathFrames[i] = createFallbackFrame("DEAD");
                deathFramesLeft[i] = createFallbackFrame("DEAD");
            }
        }
        
        // HIT ANIMATION (2 frames) - RIGHT & LEFT
        hitFrames = new GreenfootImage[2];
        hitFramesLeft = new GreenfootImage[2];
        for (int i = 0; i < 2; i++) {
            try {
                // RIGHT VERSION
                hitFrames[i] = new GreenfootImage("boss_hit_" + (i + 1) + ".png");
                hitFrames[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
                
                // LEFT VERSION (MIRROR)
                hitFramesLeft[i] = new GreenfootImage("boss_hit_" + (i + 1) + ".png");
                hitFramesLeft[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
                hitFramesLeft[i].mirrorHorizontally();
            } catch (IllegalArgumentException e) {
                hitFrames[i] = createFallbackFrame("HIT");
                hitFramesLeft[i] = createFallbackFrame("HIT");
            }
        }
    }
    
    private GreenfootImage createFallbackFrame(String label) {
        GreenfootImage img = new GreenfootImage(VISUAL_WIDTH, VISUAL_HEIGHT);
        img.setColor(Color.BLACK);
        img.fillRect(0, 0, VISUAL_WIDTH, VISUAL_HEIGHT);
        img.setColor(Color.RED);
        img.fillRect(50, 50, 150, 150);
        img.setColor(Color.YELLOW);
        img.fillOval(85, 85, 80, 80);
        img.setColor(Color.WHITE);
        img.drawString(label, 100, 130);
        return img;
    }
    
    private void createFallbackVisual() {
        GreenfootImage img = new GreenfootImage(VISUAL_WIDTH, VISUAL_HEIGHT);
        img.setColor(Color.BLACK);
        img.fillRect(0, 0, VISUAL_WIDTH, VISUAL_HEIGHT);
        img.setColor(Color.RED);
        img.fillRect(50, 50, 150, 150);
        img.setColor(Color.YELLOW);
        img.fillOval(85, 85, 80, 80);
        setImage(img);
    }

    // ========== MAIN ACT METHOD ==========

    @Override
    public void act() {
        if (isRemoved || getWorld() == null) return;
        
        if (isDying) {
            animateDeath();
            updateShadowPosition(); // ✅ Update shadow saat dying
            return;
        }
        
        // ✅ UPDATE FACING DIRECTION
        updateFacingDirection();
        
        // GLITCH TELEPORT SYSTEM
        if (isGlitching) {
            handleGlitchTeleport();
            updateShadowPosition(); // ✅ Update shadow saat glitch
            return;
        }
        
        updateAnimation();
        
        if (willTeleport) {
            startGlitchTeleport();
        } else if (isAttacking) {
            handleAttackAnimation();
        } else if (isShooting) {
            handleShooting();
        } else if (isIdleAfterAttack) {
            handleIdleAfterAttack();
        } else {
            startAttackSequence();
        }
        
        attackPlayerBoss();
        updateShadowPosition(); // ✅ Update shadow setiap frame
        
        if (attackCooldown > 0) attackCooldown--;
    }
    
    // ========== FACING DIRECTION SYSTEM ==========
    
    private void updateFacingDirection() {
        if (getWorld() == null) return;
        
        java.util.List<Player> players = getWorld().getObjects(Player.class);
        
        if (!players.isEmpty()) {
            Player player = players.get(0);
            
            if (player != null && player.getWorld() != null) {
                // Update facing based on player position
                if (player.getX() > getX()) {
                    facingRight = true;  // Player di kanan
                } else if (player.getX() < getX()) {
                    facingRight = false; // Player di kiri
                }
            }
        }
    }
    
    // ========== GLITCH TELEPORT SYSTEM ==========
    
    private void startGlitchTeleport() {
        willTeleport = false;
        isGlitching = true;
        glitchTimer = 0;
        glitchIntensity = 0;
        
        // Tentukan posisi teleport baru
        newTeleportX = Greenfoot.getRandomNumber(MAX_X - MIN_X) + MIN_X;
        newTeleportY = Greenfoot.getRandomNumber(MAX_Y - MIN_Y) + MIN_Y;
        
        // Cache base image untuk glitch effect
        cacheBaseImage();
        
        System.out.println("🌀 Boss starting glitch teleport to: " + newTeleportX + ", " + newTeleportY);
    }
    
    private void cacheBaseImage() {
        // Cache current frame dengan facing direction yang benar
        GreenfootImage[] rightFrames = null;
        GreenfootImage[] leftFrames = null;
        
        switch(currentAnimation) {
            case "idle":
                rightFrames = idleFrames;
                leftFrames = idleFramesLeft;
                break;
            case "attack":
                rightFrames = attackFrames;
                leftFrames = attackFramesLeft;
                break;
            default:
                rightFrames = idleFrames;
                leftFrames = idleFramesLeft;
                break;
        }
        
        if (rightFrames != null && leftFrames != null && currentFrame < rightFrames.length) {
            if (facingRight) {
                baseImageCache = new GreenfootImage(rightFrames[currentFrame]);
            } else {
                baseImageCache = new GreenfootImage(leftFrames[currentFrame]);
            }
        } else {
            baseImageCache = new GreenfootImage(getImage());
        }
    }
    
    private void handleGlitchTeleport() {
        glitchTimer++;
        
        // PHASE 1: GLITCH OUT (0-15 ticks)
        if (glitchTimer <= GLITCH_DURATION / 2) {
            glitchIntensity = glitchTimer * 2;
            applyGlitchEffect();
        }
        // PHASE 2: TELEPORT (frame 15)
        else if (glitchTimer == GLITCH_DURATION / 2 + 1) {
            setLocation(newTeleportX, newTeleportY);
            
            // ✅ UPDATE FACING SETELAH TELEPORT
            updateFacingDirection();
            
            System.out.println("⚡ Boss teleported to: " + getX() + ", " + getY());
        }
        // PHASE 3: GLITCH IN (16-30 ticks)
        else if (glitchTimer <= GLITCH_DURATION) {
            glitchIntensity = (GLITCH_DURATION - glitchTimer) * 2;
            applyGlitchEffect();
        }
        // PHASE 4: SELESAI
        else {
            isGlitching = false;
            isIdleAfterAttack = true;
            currentAnimation = "idle";
            currentFrame = 0;
            animationCounter = 0;
            animationFinished = false;
            animationLoopCount = 0;
            
            // Reset ke normal image dengan facing yang benar
            if (facingRight && idleFrames != null && idleFrames.length > 0) {
                setImage(idleFrames[0]);
            } else if (!facingRight && idleFramesLeft != null && idleFramesLeft.length > 0) {
                setImage(idleFramesLeft[0]);
            }
            
            baseImageCache = null;
            
            System.out.println("✓ Glitch teleport complete. Boss HP: " + bossHealth);
        }
    }
    
    private void applyGlitchEffect() {
        if (baseImageCache == null) {
            cacheBaseImage();
            if (baseImageCache == null) return;
        }
        
        // GLITCH EFFECT
        GreenfootImage glitchImage = new GreenfootImage(VISUAL_WIDTH, VISUAL_HEIGHT);
        
        // Random displacement berdasarkan intensity
        int offsetX = Greenfoot.getRandomNumber(Math.max(1, glitchIntensity)) - glitchIntensity / 2;
        int offsetY = Greenfoot.getRandomNumber(Math.max(1, glitchIntensity / 2)) - glitchIntensity / 4;
        
        // Draw base image dengan offset
        glitchImage.drawImage(baseImageCache, offsetX, offsetY);
        
        // RGB Split Effect
        if (glitchIntensity > 15 && Greenfoot.getRandomNumber(100) < 50) {
            GreenfootImage redShift = new GreenfootImage(baseImageCache);
            redShift.setTransparency(80);
            glitchImage.drawImage(redShift, offsetX + glitchIntensity / 4, offsetY);
        }
        
        // Random horizontal lines
        if (glitchIntensity > 10 && Greenfoot.getRandomNumber(100) < 30) {
            glitchImage.setColor(new Color(255, 255, 255, 120));
            int lineY = Greenfoot.getRandomNumber(VISUAL_HEIGHT);
            glitchImage.fillRect(0, lineY, VISUAL_WIDTH, 2);
        }
        
        // Transparency flicker
        if (glitchIntensity > 20) {
            int alpha = 180 + Greenfoot.getRandomNumber(76);
            glitchImage.setTransparency(alpha);
        }
        
        setImage(glitchImage);
    }
    
    // ========== ATTACK CYCLE ==========
    
    private void startAttackSequence() {
        isAttacking = true;
        playAnimation("attack");
        animationLoopCount = 0;
    }
    
    private void handleAttackAnimation() {
        if (animationFinished && animationLoopCount >= 1) {
            isAttacking = false;
            isShooting = true;
            burstCount = 0;
            burstTimer = 0;
        }
    }
    
    private void handleShooting() {
        burstTimer++;
        
        if (burstTimer >= burstDelay) {
            shootProjectile();
            burstCount++;
            burstTimer = 0;
            
            if (burstCount >= burstMax) {
                isShooting = false;
                willTeleport = true;
            }
        }
    }
    
    private void handleIdleAfterAttack() {
        if (animationFinished && animationLoopCount >= 1) {
            isIdleAfterAttack = false;
            playAnimation("idle");
        }
    }
    
    // ========== ANIMATION SYSTEM ==========
    
    private void updateAnimation() {
        animationCounter++;
        
        int speed = IDLE_ANIMATION_SPEED;
        int maxFrames = 4;
        GreenfootImage[] rightFrames = idleFrames;
        GreenfootImage[] leftFrames = idleFramesLeft;
        
        switch(currentAnimation) {
            case "idle":
                speed = IDLE_ANIMATION_SPEED;
                maxFrames = 4;
                rightFrames = idleFrames;
                leftFrames = idleFramesLeft;
                break;
                
            case "attack":
                speed = ATTACK_ANIMATION_SPEED;
                maxFrames = 8;
                rightFrames = attackFrames;
                leftFrames = attackFramesLeft;
                break;
                
            case "death":
                speed = DEATH_ANIMATION_SPEED;
                maxFrames = 6;
                rightFrames = deathFrames;
                leftFrames = deathFramesLeft;
                break;
                
            case "hit":
                speed = HIT_ANIMATION_SPEED;
                maxFrames = 2;
                rightFrames = hitFrames;
                leftFrames = hitFramesLeft;
                break;
        }
        
        if (animationCounter >= speed) {
            animationCounter = 0;
            currentFrame++;
            
            if (currentFrame >= maxFrames) {
                currentFrame = 0;
                animationFinished = true;
                animationLoopCount++;
                
                if (currentAnimation.equals("hit")) {
                    if (isAttacking) {
                        currentAnimation = "attack";
                    } else if (isShooting) {
                        currentAnimation = "attack";
                    } else if (isIdleAfterAttack) {
                        currentAnimation = "idle";
                    } else {
                        currentAnimation = "idle";
                    }
                    currentFrame = 0;
                    animationFinished = false;
                }
            } else {
                animationFinished = false;
            }
            
            // ✅ SET IMAGE BERDASARKAN FACING DIRECTION
            if (rightFrames != null && leftFrames != null && currentFrame < rightFrames.length) {
                if (facingRight) {
                    setImage(rightFrames[currentFrame]);
                } else {
                    setImage(leftFrames[currentFrame]);
                }
            }
        }
    }
    
    private void playAnimation(String animName) {
        if (!currentAnimation.equals("death")) {
            currentAnimation = animName;
            currentFrame = 0;
            animationCounter = 0;
            animationFinished = false;
            animationLoopCount = 0;
        }
    }

    // ========== COMBAT SYSTEM ==========

    private void shootProjectile() {
        World world = getWorld();
        if (world == null) return;
        
        java.util.List<Player> players = world.getObjects(Player.class);
        
        if (!players.isEmpty()) {
            Player player = players.get(0);
            
            if (player != null && player.getWorld() != null) {
                int dx = player.getX() - getX();
                int dy = player.getY() - getY();
                int angle = (int) Math.toDegrees(Math.atan2(dy, dx));
                
                BossProjectile projectile = new BossProjectile(angle);
                world.addObject(projectile, getX(), getY());
            }
        }
    }

    private void attackPlayerBoss() {
        if (attackCooldown > 0 || getWorld() == null) return;
        
        World world = getWorld();
        java.util.List<Player> players = world.getObjects(Player.class);
        
        if (!players.isEmpty()) {
            Player player = players.get(0);
            
            if (player != null && player.getWorld() != null) {
                double distance = Math.hypot(player.getX() - getX(), player.getY() - getY());
                
                if (distance <= BOSS_MELEE_RANGE) {
                    player.takeDamage();
                    attackCooldown = 90;
                }
            }
        }
    }

    public void takeDamage() {
        if (isDying || isRemoved) return;
        
        bossHealth--;
        
        playAnimation("hit");
        
        if (bossHealth <= 0) {
            isDying = true;
            playAnimation("death");
        }
    }
    
    private void animateDeath() {
        animationCounter++;
        
        if (animationCounter >= DEATH_ANIMATION_SPEED) {
            animationCounter = 0;
            currentFrame++;
            
            if (currentFrame >= 6) {
                World world = getWorld();
                if (world != null) {
                    int x = getX();
                    int y = getY();
                    
                    for (int i = 0; i < 12; i++) {
                        int ex = x + Greenfoot.getRandomNumber(120) - 60;
                        int ey = y + Greenfoot.getRandomNumber(120) - 60;
                        world.addObject(new Explosion(), ex, ey);
                    }
                    
                    removeShadow(); // ✅ HAPUS SHADOW SEBELUM REMOVE BOSS
                    isRemoved = true;
                    world.removeObject(this);
                    
                    if (world instanceof DungeonWorld) {
                        ((DungeonWorld) world).playerWins();
                    }
                }
                return;
            }
            
            // ✅ DEATH ANIMATION DENGAN FACING
            if (deathFrames != null && deathFramesLeft != null && currentFrame < deathFrames.length) {
                if (facingRight) {
                    setImage(deathFrames[currentFrame]);
                } else {
                    setImage(deathFramesLeft[currentFrame]);
                }
            }
        }
    }

    public int getBossHealth() {
        return bossHealth;
    }
}