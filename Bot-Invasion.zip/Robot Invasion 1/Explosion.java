import greenfoot.*;

public class Explosion extends Actor {
    private int currentFrame = 0;
    private int animationCounter = 0;
    private static final int ANIMATION_SPEED = 3;  // Kecepatan animasi (ticks per frame)
    private static final int TOTAL_FRAMES = 12;    // Total 12 frame
    
    private GreenfootImage[] explosionFrames;

    public Explosion() {
        loadExplosionAnimation();
        if (explosionFrames != null && explosionFrames.length > 0) {
            setImage(explosionFrames[0]);
        }
    }

    private void loadExplosionAnimation() {
        explosionFrames = new GreenfootImage[TOTAL_FRAMES];
        
        for (int i = 0; i < TOTAL_FRAMES; i++) {
            try {
                explosionFrames[i] = new GreenfootImage("explosion_" + (i + 1) + ".png");
                // Optional: Scale jika perlu
                // explosionFrames[i].scale(60, 60);
            } catch (IllegalArgumentException e) {
                System.out.println("Warning: explosion_" + (i + 1) + ".png not found!");
                // Fallback ke circle expanding jika image tidak ada
                explosionFrames[i] = createFallbackFrame(i);
            }
        }
    }
    
    private GreenfootImage createFallbackFrame(int frame) {
        // Fallback: buat efek expanding circle jika image tidak ada
        int size = 10 + (frame * 4);
        int alpha = (int)((1.0 - (frame / 12.0)) * 255);
        
        GreenfootImage img = new GreenfootImage(size, size);
        img.setColor(new Color(255, 150, 0, alpha));
        img.fillOval(0, 0, size, size);
        
        return img;
    }

    public void act() {
        animationCounter++;
        
        if (animationCounter >= ANIMATION_SPEED) {
            animationCounter = 0;
            currentFrame++;
            
            if (currentFrame >= TOTAL_FRAMES) {
                // Animasi selesai, remove explosion
                if (getWorld() != null) {
                    getWorld().removeObject(this);
                }
                return;
            }
            
            // Update ke frame berikutnya
            if (explosionFrames != null && currentFrame < explosionFrames.length) {
                setImage(explosionFrames[currentFrame]);
            }
        }
    }
}