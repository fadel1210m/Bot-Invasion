import greenfoot.*;

public class ScoreDisplay extends Actor {
    private int score = 0;
    
    // FONT SETTINGS
    private static final int FONT_SIZE = 18;
    
    // COLOR SETTINGS
    private static final Color TEXT_COLOR = new Color(220, 220, 220);
    private static final Color OUTLINE_COLOR = new Color(50, 50, 50);
    
    // ✅ TEXT POSITION ADJUSTMENT (UBAH INI!)
    private static final int TEXT_X = 33;
    private static final int TEXT_Y = 22;

    public ScoreDisplay() {
        updateScore(0);
    }

    public void updateScore(int newScore) {
        score = newScore;
        
        GreenfootImage img = new GreenfootImage(150, 30);
        img.setColor(new Color(0, 0, 0, 0));
        img.fill();
        
        img.setFont(new Font("Monospaced", true, false, FONT_SIZE));
        
        String text = "SKOR: " + score;
        
        // DRAW OUTLINE
        img.setColor(OUTLINE_COLOR);
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                if (dx != 0 || dy != 0) {
                    img.drawString(text, TEXT_X + dx, TEXT_Y + dy);
                }
            }
        }
        
        // DRAW MAIN TEXT
        img.setColor(TEXT_COLOR);
        img.drawString(text, TEXT_X, TEXT_Y);
        
        setImage(img);
    }
}