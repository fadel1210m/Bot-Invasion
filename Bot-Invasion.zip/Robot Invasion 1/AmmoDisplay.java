import greenfoot.*;

public class AmmoDisplay extends Actor {
    private int ammo = 2;
    private int reloadTimer = 0;
    
    private GreenfootImage ammoFrame;
    private GreenfootImage ammoFull;
    private GreenfootImage ammoOne;
    private GreenfootImage ammoEmpty;
    
    private static final int BAR_WIDTH = 120;
    private static final int BAR_HEIGHT = 40;

    public AmmoDisplay() {
        loadAmmoBarAssets();
        updateAmmo(2, 0);
    }
    
    private void loadAmmoBarAssets() {
        try {
            ammoFrame = new GreenfootImage("ammo_frame.png");
            ammoFrame.scale(BAR_WIDTH, BAR_HEIGHT);
            
            ammoFull = new GreenfootImage("ammo_full.png");
            ammoFull.scale(BAR_WIDTH, BAR_HEIGHT);
            
            ammoOne = new GreenfootImage("ammo_one.png");
            ammoOne.scale(BAR_WIDTH, BAR_HEIGHT);
            
            ammoEmpty = new GreenfootImage("ammo_empty.png");
            ammoEmpty.scale(BAR_WIDTH, BAR_HEIGHT);
            
            System.out.println("✓ Ammo bar assets loaded (3 states + frame)");
        } catch (IllegalArgumentException e) {
            System.out.println("⚠ Warning: Ammo bar assets not found! Using fallback visual.");
            createFallbackAmmoBar();
        }
    }
    
    private void createFallbackAmmoBar() {
        ammoFrame = createFallbackFrame();
        ammoFull = createFallbackBar(2);
        ammoOne = createFallbackBar(1);
        ammoEmpty = createFallbackBar(0);
    }
    
    private GreenfootImage createFallbackFrame() {
        GreenfootImage img = new GreenfootImage(BAR_WIDTH, BAR_HEIGHT);
        img.setColor(Color.WHITE);
        img.fill();
        img.setColor(Color.BLACK);
        img.drawRect(0, 0, BAR_WIDTH - 1, BAR_HEIGHT - 1);
        img.drawRect(1, 1, BAR_WIDTH - 3, BAR_HEIGHT - 3);
        
        img.setFont(new Font("Arial", true, false, 12));
        img.drawString("AMMO:", 5, 14);
        
        return img;
    }
    
    private GreenfootImage createFallbackBar(int bullets) {
        GreenfootImage img = new GreenfootImage(BAR_WIDTH, BAR_HEIGHT);
        img.setColor(Color.WHITE);
        img.fill();
        
        img.setColor(Color.BLACK);
        img.drawRect(0, 0, BAR_WIDTH - 1, BAR_HEIGHT - 1);
        
        img.setFont(new Font("Arial", true, false, 12));
        img.drawString("AMMO:", 5, 14);
        
        Color bulletColor;
        if (bullets == 2) {
            bulletColor = new Color(255, 215, 0);
        } else if (bullets == 1) {
            bulletColor = new Color(255, 140, 0);
        } else {
            bulletColor = new Color(150, 150, 150);
        }
        
        img.setColor(bulletColor);
        for (int i = 0; i < bullets; i++) {
            img.fillOval(50 + i * 30, 10, 18, 18);
        }
        
        img.setColor(new Color(150, 150, 150));
        for (int i = bullets; i < 2; i++) {
            img.fillOval(50 + i * 30, 10, 18, 18);
        }
        
        return img;
    }

    public void updateAmmo(int newAmmo, int reload) {
        ammo = newAmmo;
        reloadTimer = reload;
        updateImage();
    }

    private void updateImage() {
        GreenfootImage composite = new GreenfootImage(BAR_WIDTH, BAR_HEIGHT);
        
        // STEP 1: Draw frame
        if (ammoFrame != null) {
            composite.drawImage(ammoFrame, 0, 0);
        }
        
        // STEP 2: Draw ammo state dengan offset berbeda
        GreenfootImage ammoState = null;
        int offsetX = 0;
        int offsetY = 0;
        
        if (reloadTimer > 0) {
            // Reload state → ammo_empty (NO OFFSET)
            ammoState = ammoEmpty;
            offsetX = 0; // ✅ Empty tidak geser
            
            if (ammoState != null) {
                composite.drawImage(ammoState, offsetX, offsetY);
            }
            
            // Reload progress bar (tetap center)
            int progress = (int)((60 - reloadTimer) / 60.0 * 80);
            composite.setColor(new Color(255, 140, 0, 200));
            composite.fillRect(20, 28, progress, 8);
            
            composite.setColor(Color.BLACK);
            composite.drawRect(20, 28, 80, 8);
            
        } else {
            // Normal state
            if (ammo == 2) {
                ammoState = ammoFull;
                offsetX = -15; // ✅ FULL: geser kiri (ADJUST INI!)
            } else if (ammo == 1) {
                ammoState = ammoOne;
                offsetX = -10; // ✅ ONE: geser kiri (ADJUST INI!)
            } else {
                ammoState = ammoEmpty;
                offsetX = 0;  // ✅ EMPTY: tetap center
            }
            
            if (ammoState != null) {
                composite.drawImage(ammoState, offsetX, offsetY);
            }
        }
        
        setImage(composite);
    }

    public void act() {
        if (getWorld() != null) {
            DungeonWorld world = (DungeonWorld) getWorld();
            Player player = world.getPlayer();
            if (player != null) {
                updateAmmo(player.getShotsAvailable(), player.getReloadTimer());
            }
        }
    }
}