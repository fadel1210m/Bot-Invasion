import greenfoot.*;

public class GameOverScreen extends Actor {
    // FONT SETTINGS
    private static final String FONT_NAME = "Courier New";
    private static final int FONT_SIZE = 60;
    
    // COLOR SETTINGS
    private static final Color TEXT_COLOR = new Color(220, 220, 220);
    private static final Color OUTLINE_COLOR = new Color(0, 0, 0);
    
    private RetryButton retryButton;
    
    public GameOverScreen() {
        createGameOverMessage();
    }
    
    @Override
    public void addedToWorld(World world) {
        // ✅ SPAWN RETRY BUTTON DI BAWAH TEXT
        retryButton = new RetryButton();
        world.addObject(retryButton, 400, 370);
        
        System.out.println("✓ Game Over screen with retry button displayed");
    }
    
    private void createGameOverMessage() {
        GreenfootImage img = new GreenfootImage(400, 200);
        img.setColor(new Color(0, 0, 0, 0));
        img.fill();
        
        String text = "GAME OVER";
        
        img.setFont(new Font(FONT_NAME, true, false, FONT_SIZE));
        
        // Draw outline
        img.setColor(OUTLINE_COLOR);
        for (int dx = -3; dx <= 3; dx++) {
            for (int dy = -3; dy <= 3; dy++) {
                if (dx != 0 || dy != 0) {
                    img.drawString(text, 40 + dx, 120 + dy);
                }
            }
        }
        
        // Draw main text
        img.setColor(TEXT_COLOR);
        img.drawString(text, 40, 120);
        
        setImage(img);
    }
}