import greenfoot.*;

public class Player extends Actor {
    private int health = 3;
    private int maxHealth = 3;
    private int shootCooldown = 0;
    private int damageCooldown = 0;
    private int currentDirection = 0;
    private boolean isRemoved = false;
    private int shotsAvailable = 2;
    private int reloadTimer = 0;
    private static final int RELOAD_TIME = 60;
    private static final int SHOOT_COOLDOWN = 10;
    
    // ANIMASI FRAMES
    private GreenfootImage[] idleFrames;
    private GreenfootImage[] idleFramesLeft;
    private GreenfootImage[] runFrames;
    private GreenfootImage[] runFramesLeft;
    private GreenfootImage[] attackFrames;
    private GreenfootImage[] attackFramesLeft;
    private GreenfootImage[] hurtFrames;
    private GreenfootImage[] hurtFramesLeft;
    private GreenfootImage[] deathFrames;
    private GreenfootImage[] deathFramesLeft;
    
    private int currentFrame = 0;
    private int animationCounter = 0;
    private static final int ANIMATION_SPEED = 8;
    private static final int RUN_ANIMATION_SPEED = 5;
    private static final int ATTACK_ANIMATION_SPEED = 4;
    private static final int HURT_ANIMATION_SPEED = 6;
    private static final int DEATH_ANIMATION_SPEED = 10;
    
    // STATE ANIMASI
    private String currentAnimation = "idle";
    private boolean animationFinished = true;
    
    // UKURAN VISUAL DAN HITBOX
    private static final int VISUAL_WIDTH = 60;
    private static final int VISUAL_HEIGHT = 60;
    private static final int HITBOX_RADIUS = 5; 
    
    // SHADOW SYSTEM
    private PlayerShadow shadow;
    private static final int SHADOW_OFFSET_X_RIGHT = -12;
    private static final int SHADOW_OFFSET_X_LEFT = 12;
    private static final int SHADOW_OFFSET_Y = 28;
    
    // ARAH MENGHADAP
    private boolean facingRight = true;
    
    // STATE FLAGS
    private boolean isDying = false;
    private boolean isMoving = false;

    public Player() {
        loadAllAnimations();
        setImage(idleFrames[0]);
    }
    
    // ========== SHADOW SYSTEM ==========
    
    @Override
    public void addedToWorld(World world) {
        shadow = new PlayerShadow();
        int shadowX = getX() + SHADOW_OFFSET_X_RIGHT;
        int shadowY = getY() + SHADOW_OFFSET_Y;
        world.addObject(shadow, shadowX, shadowY);
    }
    
    private void updateShadowPosition() {
        if (shadow != null && shadow.getWorld() != null) {
            int offsetX = facingRight ? SHADOW_OFFSET_X_RIGHT : SHADOW_OFFSET_X_LEFT;
            shadow.setLocation(getX() + offsetX, getY() + SHADOW_OFFSET_Y);
        }
    }
    
    private void removeShadow() {
        if (shadow != null && shadow.getWorld() != null) {
            getWorld().removeObject(shadow);
            shadow = null;
        }
    }

    // ========== ANIMATION LOADING ==========

    private void loadAllAnimations() {
        // IDLE ANIMATION (4 frames)
        idleFrames = new GreenfootImage[4];
        idleFramesLeft = new GreenfootImage[4];
        for (int i = 0; i < 4; i++) {
            idleFrames[i] = new GreenfootImage("player_idle_" + (i + 1) + ".png");
            idleFrames[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            
            idleFramesLeft[i] = new GreenfootImage("player_idle_" + (i + 1) + ".png");
            idleFramesLeft[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            idleFramesLeft[i].mirrorHorizontally();
        }
        
        // RUN ANIMATION (6 frames)
        runFrames = new GreenfootImage[6];
        runFramesLeft = new GreenfootImage[6];
        for (int i = 0; i < 6; i++) {
            runFrames[i] = new GreenfootImage("player_run_" + (i + 1) + ".png");
            runFrames[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            
            runFramesLeft[i] = new GreenfootImage("player_run_" + (i + 1) + ".png");
            runFramesLeft[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            runFramesLeft[i].mirrorHorizontally();
        }
        
        // ATTACK ANIMATION (8 frames)
        attackFrames = new GreenfootImage[8];
        attackFramesLeft = new GreenfootImage[8];
        for (int i = 0; i < 8; i++) {
            attackFrames[i] = new GreenfootImage("player_attack_" + (i + 1) + ".png");
            attackFrames[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            
            attackFramesLeft[i] = new GreenfootImage("player_attack_" + (i + 1) + ".png");
            attackFramesLeft[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            attackFramesLeft[i].mirrorHorizontally();
        }
        
        // HURT ANIMATION (2 frames)
        hurtFrames = new GreenfootImage[2];
        hurtFramesLeft = new GreenfootImage[2];
        for (int i = 0; i < 2; i++) {
            hurtFrames[i] = new GreenfootImage("player_hurt_" + (i + 1) + ".png");
            hurtFrames[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            
            hurtFramesLeft[i] = new GreenfootImage("player_hurt_" + (i + 1) + ".png");
            hurtFramesLeft[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            hurtFramesLeft[i].mirrorHorizontally();
        }
        
        // DEATH ANIMATION (6 frames)
        deathFrames = new GreenfootImage[6];
        deathFramesLeft = new GreenfootImage[6];
        for (int i = 0; i < 6; i++) {
            deathFrames[i] = new GreenfootImage("player_death_" + (i + 1) + ".png");
            deathFrames[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            
            deathFramesLeft[i] = new GreenfootImage("player_death_" + (i + 1) + ".png");
            deathFramesLeft[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            deathFramesLeft[i].mirrorHorizontally();
        }
    }

    // ========== MAIN ACT METHOD ==========

    public void act() {
        if (isRemoved || getWorld() == null) return;
        
        if (isDying) {
            animateDeath();
            updateShadowPosition();
            return;
        }
        
        updateAnimation();
        
        if (currentAnimation.equals("idle") || currentAnimation.equals("run") || currentAnimation.equals("attack")) {
            handleMovement();
            handleShooting();
        }
        
        handleReload();
        checkCollisions();
        
        updateShadowPosition();
        
        if (shootCooldown > 0) shootCooldown--;
        if (damageCooldown > 0) damageCooldown--;
    }

    private void updateAnimation() {
        animationCounter++;
        
        int speed = ANIMATION_SPEED;
        int maxFrames = 4;
        GreenfootImage[] rightFrames = idleFrames;
        GreenfootImage[] leftFrames = idleFramesLeft;
        
        switch(currentAnimation) {
            case "idle":
                speed = ANIMATION_SPEED;
                maxFrames = 4;
                rightFrames = idleFrames;
                leftFrames = idleFramesLeft;
                break;
            
            case "run":
                speed = RUN_ANIMATION_SPEED;
                maxFrames = 6;
                rightFrames = runFrames;
                leftFrames = runFramesLeft;
                break;
                
            case "attack":
                speed = ATTACK_ANIMATION_SPEED;
                maxFrames = 8;
                rightFrames = attackFrames;
                leftFrames = attackFramesLeft;
                break;
                
            case "hurt":
                speed = HURT_ANIMATION_SPEED;
                maxFrames = 2;
                rightFrames = hurtFrames;
                leftFrames = hurtFramesLeft;
                break;
                
            case "death":
                speed = DEATH_ANIMATION_SPEED;
                maxFrames = 6;
                rightFrames = deathFrames;
                leftFrames = deathFramesLeft;
                break;
        }
        
        if (animationCounter >= speed) {
            animationCounter = 0;
            currentFrame++;
            
            if (currentFrame >= maxFrames) {
                if (currentAnimation.equals("idle") || currentAnimation.equals("run")) {
                    currentFrame = 0;
                } else {
                    currentFrame = 0;
                    animationFinished = true;
                    
                    if (!currentAnimation.equals("death")) {
                        currentAnimation = isMoving ? "run" : "idle";
                    }
                }
            }
            
            if (facingRight) {
                setImage(rightFrames[currentFrame]);
            } else {
                setImage(leftFrames[currentFrame]);
            }
        }
    }

    private void playAnimation(String animName) {
        if (!currentAnimation.equals("death")) {
            currentAnimation = animName;
            currentFrame = 0;
            animationCounter = 0;
            animationFinished = false;
        }
    }

    private void handleMovement() {
        if (getWorld() == null) return;
        
        int dx = 0, dy = 0;
        boolean moved = false;
        
        if (Greenfoot.isKeyDown("w")) {
            dy = -3;
            currentDirection = 270;
            moved = true;
        }
        if (Greenfoot.isKeyDown("s")) {
            dy = 3;
            currentDirection = 90;
            moved = true;
        }
        if (Greenfoot.isKeyDown("a")) {
            dx = -3;
            currentDirection = 180;
            moved = true;
            facingRight = false;
        }
        if (Greenfoot.isKeyDown("d")) {
            dx = 3;
            currentDirection = 0;
            moved = true;
            facingRight = true;
        }

        isMoving = moved;
        
        if (moved && currentAnimation.equals("idle")) {
            playAnimation("run");
        } else if (!moved && currentAnimation.equals("run")) {
            playAnimation("idle");
        }

        if (moved) {
            int oldX = getX();
            int oldY = getY();
            
            setLocation(oldX + dx, oldY + dy);
            
            if (checkCollisionWithWall()) {
                setLocation(oldX, oldY);
            }
        }
    }

    private boolean checkCollisionWithWall() {
        java.util.List<Wall> walls = getObjectsInRange(HITBOX_RADIUS, Wall.class);
        return !walls.isEmpty();
    }

    private void handleShooting() {
        if (getWorld() == null) return;
        
        if (Greenfoot.isKeyDown("space") && shootCooldown == 0 && shotsAvailable > 0) {
            playAnimation("attack");
            
            Projectile projectile = new Projectile(currentDirection);
            getWorld().addObject(projectile, getX(), getY());
            
            shotsAvailable--;
            shootCooldown = SHOOT_COOLDOWN;
            
            DungeonWorld world = (DungeonWorld) getWorld();
            if (world != null) {
                world.updateAmmo(shotsAvailable);
            }
            
            if (shotsAvailable == 0) {
                reloadTimer = RELOAD_TIME;
            }
        }
    }

    private void handleReload() {
        if (reloadTimer > 0) {
            reloadTimer--;
            
            if (reloadTimer == 0) {
                shotsAvailable = 2;
                
                DungeonWorld world = (DungeonWorld) getWorld();
                if (world != null) {
                    world.updateAmmo(shotsAvailable);
                }
            }
        }
    }

    private void checkCollisions() {
        if (getWorld() == null) return;
        
        if (damageCooldown == 0) {
            java.util.List<Enemy> enemies = getObjectsInRange(HITBOX_RADIUS, Enemy.class);
            if (!enemies.isEmpty()) {
                takeDamage();
                damageCooldown = 90;
            }
        }
        
        java.util.List<PowerUpHeart> hearts = getObjectsInRange(20, PowerUpHeart.class);
        if (!hearts.isEmpty()) {
            PowerUpHeart heart = hearts.get(0);
            gainHealth();
            heart.pickedUp();
        }
    }

    public void takeDamage() {
        if (isRemoved || damageCooldown > 0 || isDying) return;
        
        health--;
        playAnimation("hurt");
        
        DungeonWorld world = (DungeonWorld) getWorld();
        if (world != null) {
            world.updateHealth(health);
            
            if (health <= 0) {
                isDying = true;
                playAnimation("death");
            }
        }
    }

    private void animateDeath() {
        animationCounter++;
        
        if (animationCounter >= DEATH_ANIMATION_SPEED) {
            animationCounter = 0;
            currentFrame++;
            
            if (currentFrame >= 6) {
                isRemoved = true;
                
                DungeonWorld world = (DungeonWorld) getWorld();
                if (world != null) {
                    removeShadow();
                    world.removeObject(this);
                    world.gameOver();
                }
                return;
            }
            
            if (facingRight) {
                setImage(deathFrames[currentFrame]);
            } else {
                setImage(deathFramesLeft[currentFrame]);
            }
        }
    }

    public void gainHealth() {
        if (isRemoved || isDying) return;
        
        if (health < maxHealth) {
            health++;
            DungeonWorld world = (DungeonWorld) getWorld();
            if (world != null) {
                world.updateHealth(health);
            }
        }
    }

    public void restoreFullHealth() {
        health = maxHealth;
        shotsAvailable = 2;
        reloadTimer = 0;
        damageCooldown = 0;
        isDying = false;
        isMoving = false;
        
        playAnimation("idle");
        
        DungeonWorld world = (DungeonWorld) getWorld();
        if (world != null) {
            world.updateHealth(health);
            world.updateAmmo(shotsAvailable);
        }
    }

    public int getHealth() {
        return health;
    }

    public int getShotsAvailable() {
        return shotsAvailable;
    }

    public int getReloadTimer() {
        return reloadTimer;
    }
}