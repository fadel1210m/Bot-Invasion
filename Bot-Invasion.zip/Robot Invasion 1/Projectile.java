import greenfoot.*;

public class Projectile extends Actor {
    private int speed = 8;
    private boolean isRemoved = false;
    private Enemy target = null;
    
    // ✅ ANIMASI 61 FRAME
    private GreenfootImage[] projectileFrames;
    private int currentFrame = 0;
    private int animationCounter = 0;
    private static final int TOTAL_FRAMES = 61; // ✅ 61 frames
    private static final int ANIMATION_SPEED = 1; // 1 tick per frame
    
    // UKURAN PROJECTILE
    private static final int PROJECTILE_WIDTH = 75;
    private static final int PROJECTILE_HEIGHT = 36;

    public Projectile(int direction) {
        setRotation(direction);
        findTarget();
        
        loadProjectileAnimation();
    }
    
    // ========== LOAD 61 FRAME ANIMATION ==========
    
    private void loadProjectileAnimation() {
        projectileFrames = new GreenfootImage[TOTAL_FRAMES];
        
        for (int i = 0; i < TOTAL_FRAMES; i++) {
            try {
                // Load projectile_1.png hingga projectile_61.png
                projectileFrames[i] = new GreenfootImage("projectile_" + (i + 1) + ".png");
                projectileFrames[i].scale(PROJECTILE_WIDTH, PROJECTILE_HEIGHT);
            } catch (IllegalArgumentException e) {
                System.out.println("Warning: projectile_" + (i + 1) + ".png not found!");
                projectileFrames[i] = createFallbackFrame();
            }
        }
        
        // Set frame pertama
        if (projectileFrames[0] != null) {
            setImage(projectileFrames[0]);
        }
        
        System.out.println("✓ Projectile animation loaded (61 frames)");
    }
    
    private GreenfootImage createFallbackFrame() {
        // Fallback: arrow visual
        GreenfootImage img = new GreenfootImage(PROJECTILE_WIDTH, PROJECTILE_HEIGHT);
        img.setColor(Color.YELLOW);
        img.fillRect(0, 0, 20, PROJECTILE_HEIGHT);
        img.setColor(Color.ORANGE);
        img.fillPolygon(new int[]{20, PROJECTILE_WIDTH, 20}, new int[]{0, PROJECTILE_HEIGHT / 2, PROJECTILE_HEIGHT}, 3);
        return img;
    }

    // ========== MAIN ACT METHOD ==========

    public void act() {
        if (isRemoved || getWorld() == null) return;
        
        // Update animation
        updateAnimation();
        
        // Update target dan rotasi
        if (target != null && target.getWorld() != null) {
            turnTowards(target.getX(), target.getY());
        } else {
            findTarget();
        }
        
        move(speed);
        
        if (isAtEdge()) {
            safeRemove();
            return;
        }
        
        checkCollisions();
    }
    
    // ========== ANIMATION SYSTEM ==========
    
    private void updateAnimation() {
        animationCounter++;
        
        if (animationCounter >= ANIMATION_SPEED) {
            animationCounter = 0;
            currentFrame++;
            
            // Loop animation (61 frames loop terus)
            if (currentFrame >= TOTAL_FRAMES) {
                currentFrame = 0; // Kembali ke frame 1
            }
            
            // Update image
            if (projectileFrames != null && currentFrame < projectileFrames.length) {
                setImage(projectileFrames[currentFrame]);
            }
        }
    }

    // ========== TARGET FINDING ==========

    private void findTarget() {
        if (getWorld() == null) return;
        
        DungeonWorld world = (DungeonWorld) getWorld();
        
        java.util.List<Boss> bosses = world.getObjects(Boss.class);
        if (!bosses.isEmpty()) {
            target = findClosestEnemy(bosses);
            return;
        }
        
        java.util.List<EnemyType2> enemies2 = world.getObjects(EnemyType2.class);
        if (!enemies2.isEmpty()) {
            target = findClosestEnemy(enemies2);
            return;
        }
        
        java.util.List<EnemyType1> enemies1 = world.getObjects(EnemyType1.class);
        if (!enemies1.isEmpty()) {
            target = findClosestEnemy(enemies1);
            return;
        }
        
        target = null;
    }

    private <T extends Enemy> Enemy findClosestEnemy(java.util.List<T> enemies) {
        if (enemies.isEmpty()) return null;
        
        Enemy closest = null;
        double minDistance = Double.MAX_VALUE;
        
        for (Enemy enemy : enemies) {
            double distance = Math.hypot(enemy.getX() - getX(), enemy.getY() - getY());
            if (distance < minDistance) {
                minDistance = distance;
                closest = enemy;
            }
        }
        
        return closest;
    }

    // ========== COLLISION DETECTION ==========

    private void checkCollisions() {
        if (isRemoved || getWorld() == null) return;
        
        DungeonWorld world = (DungeonWorld) getWorld();
        
        // Check collision dengan Boss
        java.util.List<Boss> bosses = world.getObjects(Boss.class);
        if (!bosses.isEmpty()) {
            Boss boss = bosses.get(0);
            
            if (boss != null && boss.getWorld() != null) {
                double distance = Math.hypot(boss.getX() - getX(), boss.getY() - getY());
                
                if (distance <= 50) {
                    boss.takeDamage();
                    world.addScore(50);
                    safeRemove();
                    return;
                }
            }
        }

        // Check collision dengan EnemyType2
        EnemyType2 enemy2 = (EnemyType2) getOneIntersectingObject(EnemyType2.class);
        if (enemy2 != null && enemy2.getWorld() != null) {
            int ex = enemy2.getX();
            int ey = enemy2.getY();
            
            enemy2.safeRemove();
            
            world.addObject(new Explosion(), ex, ey);
            world.addScore(20);
            safeRemove();
            return;
        }

        // Check collision dengan EnemyType1
        EnemyType1 enemy1 = (EnemyType1) getOneIntersectingObject(EnemyType1.class);
        if (enemy1 != null && enemy1.getWorld() != null) {
            int ex = enemy1.getX();
            int ey = enemy1.getY();
            
            enemy1.safeRemove();
            
            world.addObject(new Explosion(), ex, ey);
            world.addScore(10);
            safeRemove();
            return;
        }
    }

    private void safeRemove() {
        if (!isRemoved && getWorld() != null) {
            isRemoved = true;
            getWorld().removeObject(this);
        }
    }
}