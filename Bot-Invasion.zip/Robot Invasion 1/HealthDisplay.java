import greenfoot.*;

public class HealthDisplay extends Actor {
    private int health = 3;
    
    // HEALTH BAR ASSETS (4 STATE + 1 FRAME)
    private GreenfootImage healthFrame;     // Frame health bar (background)
    private GreenfootImage healthFull;      // HP = 3 (full)
    private GreenfootImage healthTwo;       // HP = 2 (sisa 2)
    private GreenfootImage healthOne;       // HP = 1 (sisa 1)
    private GreenfootImage healthEmpty;     // HP = 0 (kosong/dead)
    
    // UKURAN VISUAL (sesuaikan dengan asset Anda)
    private static final int BAR_WIDTH = 120;   // Lebar health bar
    private static final int BAR_HEIGHT = 40;   // Tinggi health bar

    public HealthDisplay() {
        loadHealthBarAssets();
        updateHealth(3); // Initial health = 3
    }
    
    // ========== ASSET LOADING ==========
    
    private void loadHealthBarAssets() {
        try {
            // Load frame (background/border health bar)
            healthFrame = new GreenfootImage("health_frame.png");
            healthFrame.scale(BAR_WIDTH, BAR_HEIGHT);
            
            // Load 4 health bar states
            healthFull = new GreenfootImage("health_full.png");    // HP 3
            healthFull.scale(BAR_WIDTH, BAR_HEIGHT);
            
            healthTwo = new GreenfootImage("health_two.png");      // HP 2
            healthTwo.scale(BAR_WIDTH, BAR_HEIGHT);
            
            healthOne = new GreenfootImage("health_one.png");      // HP 1
            healthOne.scale(BAR_WIDTH, BAR_HEIGHT);
            
            healthEmpty = new GreenfootImage("health_empty.png");  // HP 0
            healthEmpty.scale(BAR_WIDTH, BAR_HEIGHT);
            
            System.out.println("✓ Health bar assets loaded (4 states + frame)");
        } catch (IllegalArgumentException e) {
            System.out.println("⚠ Warning: Health bar assets not found! Using fallback visual.");
            createFallbackHealthBar();
        }
    }
    
    private void createFallbackHealthBar() {
        // Fallback jika assets tidak ditemukan
        healthFrame = createFallbackFrame();
        healthFull = createFallbackBar(3);
        healthTwo = createFallbackBar(2);
        healthOne = createFallbackBar(1);
        healthEmpty = createFallbackBar(0);
    }
    
    private GreenfootImage createFallbackFrame() {
        GreenfootImage img = new GreenfootImage(BAR_WIDTH, BAR_HEIGHT);
        img.setColor(Color.WHITE);
        img.fill();
        img.setColor(Color.BLACK);
        img.drawRect(0, 0, BAR_WIDTH - 1, BAR_HEIGHT - 1);
        img.drawRect(1, 1, BAR_WIDTH - 3, BAR_HEIGHT - 3);
        
        // Label "HP"
        img.setFont(new Font("Arial", true, false, 14));
        img.drawString("HP:", 5, 16);
        
        return img;
    }
    
    private GreenfootImage createFallbackBar(int hp) {
        GreenfootImage img = new GreenfootImage(BAR_WIDTH, BAR_HEIGHT);
        img.setColor(Color.WHITE);
        img.fill();
        
        // Draw border
        img.setColor(Color.BLACK);
        img.drawRect(0, 0, BAR_WIDTH - 1, BAR_HEIGHT - 1);
        
        // Label "HP"
        img.setFont(new Font("Arial", true, false, 14));
        img.drawString("HP:", 5, 16);
        
        // Draw hearts based on HP
        Color heartColor;
        if (hp >= 3) {
            heartColor = new Color(0, 255, 0); // Green (full)
        } else if (hp == 2) {
            heartColor = new Color(255, 255, 0); // Yellow (half)
        } else if (hp == 1) {
            heartColor = new Color(255, 100, 0); // Orange (low)
        } else {
            heartColor = new Color(150, 150, 150); // Grey (empty)
        }
        
        img.setColor(heartColor);
        for (int i = 0; i < hp; i++) {
            img.fillOval(35 + i * 25, 8, 20, 20);
        }
        
        // Draw empty hearts (grey)
        img.setColor(new Color(150, 150, 150));
        for (int i = hp; i < 3; i++) {
            img.fillOval(35 + i * 25, 8, 20, 20);
        }
        
        return img;
    }

    // ========== UPDATE HEALTH ==========

    public void updateHealth(int newHealth) {
        health = newHealth;
        updateImage();
    }

    private void updateImage() {
        // Composite image: Frame + Health state
        GreenfootImage composite = new GreenfootImage(BAR_WIDTH, BAR_HEIGHT);
        
        // STEP 1: Draw frame (background layer)
        if (healthFrame != null) {
            composite.drawImage(healthFrame, 0, 0);
        }
        
        // STEP 2: Draw health state (overlay layer)
        GreenfootImage healthState = null;
        
        if (health >= 3) {
            healthState = healthFull;       // ✅ HP 3 (full)
        } else if (health == 2) {
            healthState = healthTwo;        // ✅ HP 2 (sisa 2)
        } else if (health == 1) {
            healthState = healthOne;        // ✅ HP 1 (sisa 1)
        } else {
            healthState = healthEmpty;      // ✅ HP 0 (kosong)
        }
        
        if (healthState != null) {
            composite.drawImage(healthState, 0, 0);
        }
        
        setImage(composite);
    }
}