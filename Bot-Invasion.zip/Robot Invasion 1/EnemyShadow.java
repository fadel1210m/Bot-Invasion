import greenfoot.*;

public class EnemyShadow extends Actor {
    private static final int SHADOW_WIDTH = 35;   // Lebih kecil dari player
    private static final int SHADOW_HEIGHT = 12;  // Flat oval
    
    public EnemyShadow() {
        GreenfootImage shadow = new GreenfootImage(SHADOW_WIDTH, SHADOW_HEIGHT);
        shadow.setColor(new Color(0, 0, 0, 100)); // Hitam semi-transparan
        shadow.fillOval(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
        setImage(shadow);
    }
}