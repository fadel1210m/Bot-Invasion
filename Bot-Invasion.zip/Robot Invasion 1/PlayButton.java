import greenfoot.*;

public class PlayButton extends Actor {
    private static final int BUTTON_WIDTH = 80;
    private static final int BUTTON_HEIGHT = 80;

    public PlayButton() {
        loadButtonImage();
    }
    
    private void loadButtonImage() {
        try {
            GreenfootImage button = new GreenfootImage("play_button.png");
            button.scale(BUTTON_WIDTH, BUTTON_HEIGHT);
            setImage(button);
            System.out.println("✓ Play button image loaded");
        } catch (IllegalArgumentException e) {
            System.out.println("⚠ play_button.png not found, using fallback");
            createFallbackButton();
        }
    }
    
    private void createFallbackButton() {
        GreenfootImage img = new GreenfootImage(BUTTON_WIDTH, BUTTON_HEIGHT);
        
        img.setColor(new Color(100, 200, 100));
        img.fillRect(0, 0, BUTTON_WIDTH, BUTTON_HEIGHT);
        
        img.setColor(new Color(50, 150, 50));
        img.fillRect(0, 0, BUTTON_WIDTH, 8);
        img.fillRect(0, BUTTON_HEIGHT - 8, BUTTON_WIDTH, 8);
        img.fillRect(0, 0, 8, BUTTON_HEIGHT);
        img.fillRect(BUTTON_WIDTH - 8, 0, 8, BUTTON_HEIGHT);
        
        img.setColor(Color.WHITE);
        img.setFont(new Font("Monospaced", true, false, 32));
        img.drawString("PLAY", 60, 55);
        
        setImage(img);
    }
    
    public void act() {
        // ✅ CHECK MOUSE CLICK SETIAP FRAME
        if (Greenfoot.mouseClicked(this)) {
            System.out.println("\n🖱️ MOUSE CLICKED ON PLAY BUTTON!");
            handleClick();
        }
        
        // Hover effect
        if (Greenfoot.mouseMoved(this)) {
            GreenfootImage img = new GreenfootImage(getImage());
            img.setTransparency(230);
            setImage(img);
        } else if (Greenfoot.mouseMoved(null)) {
            loadButtonImage();
        }
    }
    
    private void handleClick() {
        System.out.println("📌 PlayButton.handleClick() EXECUTED");
        
        World world = getWorld();
        System.out.println("   World = " + world);
        
        if (world != null) {
            System.out.println("   World class = " + world.getClass().getName());
            
            if (world instanceof DungeonWorld) {
                System.out.println("   ✓ World is DungeonWorld!");
                
                DungeonWorld dungeonWorld = (DungeonWorld) world;
                
                // Remove start screen first
                java.util.List<StartScreen> screens = world.getObjects(StartScreen.class);
                System.out.println("   StartScreen count = " + screens.size());
                
                if (!screens.isEmpty()) {
                    StartScreen startScreen = screens.get(0);
                    System.out.println("   Calling startScreen.removeStartScreen()...");
                    startScreen.removeStartScreen();
                }
                
                // Start game
                System.out.println("   Calling dungeonWorld.startGame()...");
                dungeonWorld.startGame();
                System.out.println("   ✓ dungeonWorld.startGame() COMPLETED\n");
                
            } else {
                System.out.println("   ❌ ERROR: World is NOT DungeonWorld!");
            }
        } else {
            System.out.println("   ❌ ERROR: World is NULL!");
        }
    }
}