import greenfoot.*;

public class PowerUpHeart extends Actor {
    private int pulse = 0;
    private int visualType; // 1, 2, atau 3 (random)
    
    // SHADOW SYSTEM
    private PowerUpShadow shadow;
    private static final int SHADOW_OFFSET_Y = 20; // Jarak shadow dari powerup
    
    // ANIMATION
    private static final int FLOAT_AMPLITUDE = 3; // Tinggi float animation
    private int floatCounter = 0;
    private int baseY; // Posisi Y awal
    
    // UKURAN VISUAL
    private static final int VISUAL_WIDTH = 40;
    private static final int VISUAL_HEIGHT = 40;
    
    // ASSET IMAGES
    private GreenfootImage[] heartImages;

    public PowerUpHeart() {
        // Pilih visual type random (1, 2, atau 3)
        visualType = Greenfoot.getRandomNumber(3) + 1;
        
        loadHeartImages();
        updateImage();
    }
    
    // ========== SHADOW SYSTEM ==========
    
    @Override
    public void addedToWorld(World world) {
        // Spawn shadow saat powerup ditambahkan ke world
        shadow = new PowerUpShadow();
        baseY = getY(); // Simpan posisi Y awal
        world.addObject(shadow, getX(), getY() + SHADOW_OFFSET_Y);
        
        System.out.println("✓ PowerUp type " + visualType + " spawned with shadow");
    }
    
    private void updateShadowPosition() {
        // Update posisi shadow (tetap di ground, tidak ikut float)
        if (shadow != null && shadow.getWorld() != null) {
            shadow.setLocation(getX(), baseY + SHADOW_OFFSET_Y);
        }
    }
    
    private void removeShadow() {
        // Hapus shadow saat powerup diambil
        if (shadow != null && shadow.getWorld() != null) {
            getWorld().removeObject(shadow);
            shadow = null;
            System.out.println("✓ PowerUp shadow removed");
        }
    }
    
    // ========== ASSET LOADING ==========
    
    private void loadHeartImages() {
        heartImages = new GreenfootImage[3];
        
        for (int i = 0; i < 3; i++) {
            try {
                // Load image: heart1.png, heart2.png, heart3.png
                heartImages[i] = new GreenfootImage("heart" + (i + 1) + ".png");
                heartImages[i].scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            } catch (IllegalArgumentException e) {
                System.out.println("Warning: heart" + (i + 1) + ".png not found! Using fallback visual.");
                // Fallback ke visual default
                heartImages[i] = createFallbackHeart(i);
            }
        }
    }
    
    private GreenfootImage createFallbackHeart(int type) {
        // Fallback: buat heart visual yang berbeda untuk setiap type
        GreenfootImage img = new GreenfootImage(VISUAL_WIDTH, VISUAL_HEIGHT);
        
        switch(type) {
            case 0: // Heart type 1 - Pink
                img.setColor(new Color(255, 100, 150));
                img.fillOval(0, 0, VISUAL_WIDTH, VISUAL_HEIGHT);
                img.setColor(new Color(255, 150, 200));
                img.fillOval(5, 5, 30, 30);
                break;
            case 1: // Heart type 2 - Red
                img.setColor(new Color(255, 50, 50));
                img.fillOval(0, 0, VISUAL_WIDTH, VISUAL_HEIGHT);
                img.setColor(new Color(255, 100, 100));
                img.fillOval(5, 5, 30, 30);
                break;
            case 2: // Heart type 3 - Gold
                img.setColor(new Color(255, 215, 0));
                img.fillOval(0, 0, VISUAL_WIDTH, VISUAL_HEIGHT);
                img.setColor(new Color(255, 240, 100));
                img.fillOval(5, 5, 30, 30);
                break;
        }
        
        // Inner circle untuk efek depth
        img.setColor(Color.WHITE);
        img.fillOval(15, 15, 10, 10);
        
        return img;
    }

    // ========== ANIMATION & UPDATE ==========

    public void act() {
        if (getWorld() == null) return;
        
        pulse++;
        floatCounter++;
        
        // Float animation (naik-turun)
        animateFloat();
        
        // Pulse animation (scale up/down)
        if (pulse % 10 == 0) {
            updateImage();
        }
        
        // Update shadow position
        updateShadowPosition();
    }
    
    private void animateFloat() {
        // Floating effect (sine wave)
        double floatOffset = Math.sin(floatCounter * 0.1) * FLOAT_AMPLITUDE;
        setLocation(getX(), baseY + (int)floatOffset);
    }

    private void updateImage() {
        // Pulse effect (scale animation)
        int size = VISUAL_WIDTH + (int)(Math.sin(pulse * 0.1) * 5);
        
        if (heartImages != null && visualType >= 1 && visualType <= 3) {
            GreenfootImage img = new GreenfootImage(heartImages[visualType - 1]);
            img.scale(size, size);
            setImage(img);
        }
    }
    
    // ========== PICKUP SYSTEM ==========
    
    public void pickedUp() {
        // Method dipanggil dari Player.checkCollisions()
        removeShadow(); // ✅ HAPUS SHADOW SEBELUM REMOVE POWERUP
        
        if (getWorld() != null) {
            getWorld().removeObject(this);
        }
    }
}