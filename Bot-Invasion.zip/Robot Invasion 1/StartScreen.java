import greenfoot.*;

public class StartScreen extends Actor {
    private PlayButton playButton;

    public StartScreen() {
        createBlurOverlay();
    }
    
    @Override
    public void addedToWorld(World world) {
        playButton = new PlayButton();
        world.addObject(playButton, 400, 300);
    }
    
    private void createBlurOverlay() {
        GreenfootImage overlay = new GreenfootImage(800, 600);
        
        overlay.setColor(new Color(0, 0, 0, 180));
        overlay.fill();
        
        overlay.setColor(new Color(0, 0, 0, 100));
        overlay.fillRect(100, 100, 600, 400);
        
        setImage(overlay);
    }
    
    public void removeStartScreen() {
        World world = getWorld();
        if (world != null) {
            if (playButton != null && playButton.getWorld() != null) {
                world.removeObject(playButton);
            }
            
            world.removeObject(this);
        }
    }
}