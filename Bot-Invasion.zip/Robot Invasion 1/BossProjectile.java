import greenfoot.*;

public class BossProjectile extends Actor {
    private int speed = 4;
    private boolean isRemoved = false;
    private int direction;
    private static final int PROJECTILE_HITBOX = 12;
    
    // ANIMASI 30 FRAME
    private GreenfootImage[] projectileFrames;
    private int currentFrame = 0;
    private int animationCounter = 0;
    private static final int TOTAL_FRAMES = 30;
    private static final int ANIMATION_SPEED = 2;
    
    // UKURAN PROJECTILE
    private static final int PROJECTILE_WIDTH = 30;
    private static final int PROJECTILE_HEIGHT = 30;

    public BossProjectile(int direction) {
        this.direction = direction;
        setRotation(direction);
        
        loadProjectileAnimation();
    }
    
    private void loadProjectileAnimation() {
        projectileFrames = new GreenfootImage[TOTAL_FRAMES];
        
        for (int i = 0; i < TOTAL_FRAMES; i++) {
            try {
                projectileFrames[i] = new GreenfootImage("boss_projectile_" + (i + 1) + ".png");
                projectileFrames[i].scale(PROJECTILE_WIDTH, PROJECTILE_HEIGHT);
            } catch (IllegalArgumentException e) {
                projectileFrames[i] = createFallbackFrame();
            }
        }
        
        if (projectileFrames[0] != null) {
            setImage(projectileFrames[0]);
        }
    }
    
    private GreenfootImage createFallbackFrame() {
        GreenfootImage img = new GreenfootImage(PROJECTILE_WIDTH, PROJECTILE_HEIGHT);
        img.setColor(Color.RED);
        img.fillOval(0, 0, PROJECTILE_WIDTH, PROJECTILE_HEIGHT);
        img.setColor(new Color(255, 100, 0));
        img.fillOval(5, 5, PROJECTILE_WIDTH - 10, PROJECTILE_HEIGHT - 10);
        return img;
    }

    public void act() {
        if (isRemoved || getWorld() == null) return;
        
        updateAnimation();
        move(speed);
        
        if (isAtEdge()) {
            safeRemove();
            return;
        }
        
        checkCollisions();
    }
    
    private void updateAnimation() {
        animationCounter++;
        
        if (animationCounter >= ANIMATION_SPEED) {
            animationCounter = 0;
            currentFrame++;
            
            if (currentFrame >= TOTAL_FRAMES) {
                currentFrame = 0;
            }
            
            if (projectileFrames != null && currentFrame < projectileFrames.length) {
                setImage(projectileFrames[currentFrame]);
            }
        }
    }

    private void checkCollisions() {
        if (isRemoved || getWorld() == null) return;

        DungeonWorld world = (DungeonWorld) getWorld();
        Player player = world.getPlayer();
        
        if (player != null && player.getWorld() != null) {
            double distance = Math.hypot(player.getX() - getX(), player.getY() - getY());
            
            if (distance <= PROJECTILE_HITBOX) {
                player.takeDamage();
                safeRemove();
                return;
            }
        }
        
        Projectile playerProj = (Projectile) getOneIntersectingObject(Projectile.class);
        if (playerProj != null && playerProj.getWorld() != null) {
            world.addObject(new Explosion(), getX(), getY());
            world.removeObject(playerProj);
            safeRemove();
            return;
        }
    }

    private void safeRemove() {
        if (!isRemoved && getWorld() != null) {
            isRemoved = true;
            getWorld().removeObject(this);
        }
    }
}