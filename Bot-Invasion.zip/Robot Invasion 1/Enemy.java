import greenfoot.*;

public abstract class Enemy extends Actor {
    protected int speed = 1;
    protected int attackCooldown = 0;
    protected boolean isRemoved = false;
    protected static final int ATTACK_RANGE = 15;

    public void act() {
        if (isRemoved || getWorld() == null) return;
        
        // DEBUG: Print untuk cek apakah act() dipanggil
        // System.out.println("Enemy act() called at: " + getX() + ", " + getY());
        
        moveTowardsPlayer();
        checkWallCollision();
        attackPlayer();
        
        if (attackCooldown > 0) attackCooldown--;
    }

    protected void moveTowardsPlayer() {
        if (getWorld() == null) return;
        
        // CARA PALING SEDERHANA - LANGSUNG CARI PLAYER
        Actor player = getWorld().getObjects(Player.class).isEmpty() ? null : getWorld().getObjects(Player.class).get(0);
        
        if (player != null) {
            // DEBUG: Print untuk cek player ditemukan
            // System.out.println("Player found! Moving towards player...");
            
            // Hadap ke player
            turnTowards(player.getX(), player.getY());
            
            // Gerak ke depan dengan speed
            int oldX = getX();
            int oldY = getY();
            
            move(speed);
            
            // DEBUG: Print untuk cek movement
            // System.out.println("Moved from (" + oldX + "," + oldY + ") to (" + getX() + "," + getY() + ")");
        } else {
            // DEBUG: Print jika player tidak ditemukan
            // System.out.println("Player not found!");
        }
    }

    protected void checkWallCollision() {
        if (getWorld() == null) return;
        
        Wall wall = (Wall) getOneIntersectingObject(Wall.class);
        if (wall != null) {
            move(-speed);
            turn(Greenfoot.getRandomNumber(90) - 45);
        }
    }

    protected void attackPlayer() {
        if (attackCooldown > 0 || getWorld() == null) return;
        
        Actor player = getWorld().getObjects(Player.class).isEmpty() ? null : getWorld().getObjects(Player.class).get(0);
        
        if (player != null) {
            double distance = Math.hypot(player.getX() - getX(), player.getY() - getY());
            
            if (distance <= ATTACK_RANGE) {
                ((Player) player).takeDamage();
                attackCooldown = 90;
            }
        }
    }
    
    public void safeRemove() {
        if (!isRemoved && getWorld() != null) {
            isRemoved = true;
            
            World world = getWorld();
            if (world instanceof DungeonWorld) {
                ((DungeonWorld) world).enemyKilled();
            }
            
            getWorld().removeObject(this);
        }
    }
}