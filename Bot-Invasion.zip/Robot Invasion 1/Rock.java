import greenfoot.*;

public class Rock extends Actor {
    // UKURAN VISUAL
    private static final int VISUAL_WIDTH = 40;  // Sesuaikan dengan ukuran asset Anda
    private static final int VISUAL_HEIGHT = 40; // Sesuaikan dengan ukuran asset Anda

    public Rock() {
        loadRockImage();
    }
    
    private void loadRockImage() {
        try {
            // Load image dari asset: rock.png
            GreenfootImage rockImage = new GreenfootImage("rock.png");
            rockImage.scale(VISUAL_WIDTH, VISUAL_HEIGHT);
            setImage(rockImage);
            
            System.out.println("✓ Rock image loaded: rock.png");
        } catch (IllegalArgumentException e) {
            System.out.println("⚠ Warning: rock.png not found! Using fallback visual.");
            createFallbackVisual();
        }
    }
    
    private void createFallbackVisual() {
        // Fallback: batu abu-abu dengan texture
        GreenfootImage img = new GreenfootImage(VISUAL_WIDTH, VISUAL_HEIGHT);
        
        // Background abu-abu gelap
        img.setColor(new Color(80, 80, 80));
        img.fillOval(0, 0, VISUAL_WIDTH, VISUAL_HEIGHT);
        
        // Layer 2: abu-abu medium
        img.setColor(new Color(120, 120, 120));
        img.fillOval(5, 5, VISUAL_WIDTH - 10, VISUAL_HEIGHT - 10);
        
        // Layer 3: abu-abu terang (highlight)
        img.setColor(new Color(160, 160, 160));
        img.fillOval(15, 10, 20, 20);
        
        // Crack texture
        img.setColor(new Color(60, 60, 60));
        img.drawLine(20, 15, 35, 40);
        img.drawLine(25, 20, 30, 35);
        
        setImage(img);
    }
    
    // Rock adalah objek statis untuk hiasan, tidak perlu act()
}