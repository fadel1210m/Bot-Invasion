import greenfoot.*;

public class PlayerShadow extends Actor {
    private static final int SHADOW_WIDTH = 40;
    private static final int SHADOW_HEIGHT = 15;
    
    public PlayerShadow() {
        GreenfootImage shadow = new GreenfootImage(SHADOW_WIDTH, SHADOW_HEIGHT);
        shadow.setColor(new Color(0, 0, 0, 100)); // Hitam semi-transparan
        shadow.fillOval(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
        setImage(shadow);
    }
    
    // Shadow tidak punya act() - hanya visual statis
}