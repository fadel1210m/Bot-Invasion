import greenfoot.*;

public class RetryButton extends Actor {
    private static final int BUTTON_WIDTH = 150;
    private static final int BUTTON_HEIGHT = 60;
    
    private boolean isHovered = false;

    public RetryButton() {
        loadButtonImage();
    }
    
    private void loadButtonImage() {
        try {
            GreenfootImage button = new GreenfootImage("retry_button.png");
            button.scale(BUTTON_WIDTH, BUTTON_HEIGHT);
            setImage(button);
            
            System.out.println("✓ Retry button loaded");
        } catch (IllegalArgumentException e) {
            System.out.println("⚠ Warning: retry_button.png not found! Using fallback.");
            createFallbackButton();
        }
    }
    
    private void createFallbackButton() {
        GreenfootImage img = new GreenfootImage(BUTTON_WIDTH, BUTTON_HEIGHT);
        
        img.setColor(new Color(200, 100, 100));
        img.fillRect(0, 0, BUTTON_WIDTH, BUTTON_HEIGHT);
        
        img.setColor(new Color(150, 50, 50));
        img.fillRect(0, 0, BUTTON_WIDTH, 6);
        img.fillRect(0, BUTTON_HEIGHT - 6, BUTTON_WIDTH, 6);
        img.fillRect(0, 0, 6, BUTTON_HEIGHT);
        img.fillRect(BUTTON_WIDTH - 6, 0, 6, BUTTON_HEIGHT);
        
        img.setColor(Color.WHITE);
        img.setFont(new Font("Courier New", true, false, 24));
        img.drawString("RETRY", 35, 40);
        
        setImage(img);
    }
    
    public void act() {
        checkClick();
        checkHover();
    }
    
    private void checkClick() {
        if (Greenfoot.mouseClicked(this)) {
            restartGame();
        }
    }
    
    private void checkHover() {
        if (Greenfoot.mouseMoved(this)) {
            isHovered = true;
            applyHoverEffect();
        } else if (Greenfoot.mouseMoved(null)) {
            isHovered = false;
            loadButtonImage();
        }
    }
    
    private void applyHoverEffect() {
        GreenfootImage img = new GreenfootImage(getImage());
        img.setTransparency(230);
        setImage(img);
    }
    
    private void restartGame() {
        System.out.println("\n🔄 RETRY button clicked! Restarting game...\n");
        
        // ✅ STOP MUSIC DARI WORLD LAMA
        DungeonWorld oldWorld = (DungeonWorld) getWorld();
        if (oldWorld != null) {
            oldWorld.stopMusic();
        }
        
        // Restart world (buat world baru)
        DungeonWorld newWorld = new DungeonWorld();
        Greenfoot.setWorld(newWorld);
        
        // ✅ AUTO-START MUSIC DI WORLD BARU
        Greenfoot.delay(5); // Slight delay untuk stabilitas
        newWorld.startMusicManually();
    }
}