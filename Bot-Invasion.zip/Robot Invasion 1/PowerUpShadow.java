import greenfoot.*;

public class PowerUpShadow extends Actor {
    private static final int SHADOW_WIDTH = 30;  // Lebih kecil dari enemy
    private static final int SHADOW_HEIGHT = 10; // Flat untuk powerup
    
    public PowerUpShadow() {
        GreenfootImage shadow = new GreenfootImage(SHADOW_WIDTH, SHADOW_HEIGHT);
        shadow.setColor(new Color(0, 0, 0, 80)); // Hitam semi-transparan
        shadow.fillOval(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
        setImage(shadow);
    }
}