import greenfoot.*;

public class BossShadow extends Actor {
    private static final int SHADOW_WIDTH = 100;  // Lebih besar untuk boss
    private static final int SHADOW_HEIGHT = 30;  // Lebih besar untuk boss
    
    public BossShadow() {
        GreenfootImage shadow = new GreenfootImage(SHADOW_WIDTH, SHADOW_HEIGHT);
        shadow.setColor(new Color(0, 0, 0, 120)); // Sedikit lebih gelap
        shadow.fillOval(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
        setImage(shadow);
    }
}