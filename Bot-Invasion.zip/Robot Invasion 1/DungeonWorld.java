import greenfoot.*;

public class DungeonWorld extends World {
    private Player player;
    private HealthDisplay healthDisplay;
    private WaveDisplay waveDisplay;
    private ScoreDisplay scoreDisplay;
    private AmmoDisplay ammoDisplay;
    private int currentWave = 0;
    private int score = 0;
    private int powerUpTimer = 0;
    private boolean waveInProgress = false;
    private boolean gameEnded = false;
    
    private boolean gameStarted = false;
    
    // BACKGROUND MUSIC
    private GreenfootSound bgm;
    private boolean musicStarted = false;
    
    private int totalEnemiesInWave = 30;
    private int enemiesSpawned = 0;
    private int enemiesKilled = 0;
    private int batchSize = 6;
    private int spawnDelay = 12;
    private int currentSpawnDelay = 0;
    private int enemiesInCurrentBatch = 0;
    private boolean waitingForBatchClear = false;

    public DungeonWorld() {    
        super(800, 600, 1);
        
        loadCustomBackground();
        prepare();
        loadBackgroundMusic();
    }
    
    private void loadCustomBackground() {
        try {
            GreenfootImage background = new GreenfootImage("background.png");
            background.scale(getWidth(), getHeight());
            setBackground(background);
            System.out.println("✓ Background loaded");
        } catch (IllegalArgumentException e) {
            createFallbackBackground();
        }
    }
    
    private void createFallbackBackground() {
        GreenfootImage bg = new GreenfootImage(getWidth(), getHeight());
        bg.setColor(new Color(20, 20, 30));
        bg.fill();
        setBackground(bg);
    }
    
    private void loadBackgroundMusic() {
        try {
            bgm = new GreenfootSound("bgm.mp3");
            bgm.setVolume(50);
            System.out.println("✓ BGM loaded");
        } catch (Exception e) {
            System.out.println("⚠ bgm.mp3 not found");
        }
    }
    
    // ========== MUSIC CONTROL METHODS ==========
    
    public void started() {
        if (bgm != null) {
            if (!musicStarted) {
                bgm.playLoop();
                musicStarted = true;
                System.out.println("♪ BGM started");
            } else {
                bgm.playLoop();
                System.out.println("▶ BGM resumed");
            }
        }
    }
    
    public void stopped() {
        if (bgm != null && musicStarted) {
            bgm.pause();
            System.out.println("⏸ BGM paused");
        }
    }
    
    // ✅ METHOD BARU: Stop music (untuk retry)
    public void stopMusic() {
        if (bgm != null) {
            bgm.stop();
            musicStarted = false;
            System.out.println("🔇 Music stopped for restart");
        }
    }
    
    // ✅ METHOD BARU: Start music manual (setelah retry)
    public void startMusicManually() {
        if (bgm != null && !musicStarted) {
            bgm.playLoop();
            musicStarted = true;
            System.out.println("♪ Music started after retry!");
        }
    }
    
    // ==========================================

    private void prepare() {
        createWalls();
        placeRocksManually();
        
        player = new Player();
        addObject(player, 400, 300);
        
        healthDisplay = new HealthDisplay();
        addObject(healthDisplay, 70, 30);
        
        ammoDisplay = new AmmoDisplay();
        addObject(ammoDisplay, 70, 80);
        
        scoreDisplay = new ScoreDisplay();
        addObject(scoreDisplay, 70, 130);
        
        waveDisplay = new WaveDisplay();
        addObject(waveDisplay, 70, 180);
        
        addObject(new StartScreen(), 400, 300);
        
        System.out.println("✓ Setup complete - waiting for PLAY button");
    }
    
    public void startGame() {
        if (!gameStarted) {
            gameStarted = true;
            startNextWave();
            System.out.println("✓ Game started!");
        }
    }
    
    private void placeRocksManually() {
        addObject(new Rock(), 630, 90);
        addObject(new Rock(), 720, 200);
        addObject(new Rock(), 600, 400);
        addObject(new Rock(), 300, 520);
    }
    
    private void createWalls() {
        for (int x = 0; x < getWidth(); x += 20) {
            addObject(new Wall(), x, 10);
            addObject(new Wall(), x, getHeight() - 10);
        }
        
        for (int y = 0; y < getHeight(); y += 20) {
            addObject(new Wall(), 10, y);
            addObject(new Wall(), getWidth() - 10, y);
        }
    }

    public void act() {
        if (!gameStarted || gameEnded) return;
        
        powerUpTimer++;
        if (powerUpTimer >= 600) {
            spawnPowerUp();
            powerUpTimer = 0;
        }
        
        handleBatchSpawning();
    }

    private void handleBatchSpawning() {
        if (!waveInProgress) return;
        
        int currentEnemiesAlive = 0;
        if (currentWave < 3) {
            currentEnemiesAlive = getObjects(Enemy.class).size();
        } else {
            currentEnemiesAlive = getObjects(Boss.class).size();
        }
        
        if (enemiesSpawned >= totalEnemiesInWave && currentEnemiesAlive == 0) {
            waveCompleted();
            return;
        }
        
        if (waitingForBatchClear) {
            if (currentEnemiesAlive == 0) {
                waitingForBatchClear = false;
                enemiesInCurrentBatch = 0;
                Greenfoot.delay(30);
            }
            return;
        }
        
        if (enemiesSpawned < totalEnemiesInWave) {
            if (enemiesInCurrentBatch < batchSize) {
                currentSpawnDelay++;
                
                if (currentSpawnDelay >= spawnDelay) {
                    spawnEnemyFromEdge();
                    enemiesSpawned++;
                    enemiesInCurrentBatch++;
                    currentSpawnDelay = 0;
                }
            } else {
                waitingForBatchClear = true;
            }
        }
    }

    private void spawnEnemyFromEdge() {
        int side = Greenfoot.getRandomNumber(4);
        int x = 0, y = 0;
        
        switch(side) {
            case 0:
                x = Greenfoot.getRandomNumber(700) + 50;
                y = 50;
                break;
            case 1:
                x = 750;
                y = Greenfoot.getRandomNumber(500) + 50;
                break;
            case 2:
                x = Greenfoot.getRandomNumber(700) + 50;
                y = 550;
                break;
            case 3:
                x = 50;
                y = Greenfoot.getRandomNumber(500) + 50;
                break;
        }
        
        Enemy enemy = null;
        if (currentWave == 1) {
            enemy = new EnemyType1();
        } else if (currentWave == 2) {
            enemy = new EnemyType2();
        }
        
        if (enemy != null) {
            addObject(enemy, x, y);
        }
    }

    private void waveCompleted() {
        waveInProgress = false;
        
        showWaveCompleteMessage(currentWave);
        Greenfoot.delay(90);
        
        if (currentWave < 2) {
            startNextWave();
        } else {
            startBossFight();
        }
    }

    private void showWaveCompleteMessage(int wave) {
        WaveCompleteMessage msg = new WaveCompleteMessage(wave);
        addObject(msg, 400, 300);
        Greenfoot.delay(60);
        removeObject(msg);
    }

    private void startNextWave() {
        if (gameEnded) return;
        
        currentWave++;
        waveDisplay.updateWave(currentWave);
        waveInProgress = true;
        
        if (player != null && player.getWorld() != null) {
            player.restoreFullHealth();
        }
        
        enemiesSpawned = 0;
        enemiesKilled = 0;
        enemiesInCurrentBatch = 0;
        currentSpawnDelay = 0;
        waitingForBatchClear = false;
        
        System.out.println("=== WAVE " + currentWave + " STARTED ===");
    }

    private void startBossFight() {
        currentWave = 3;
        waveDisplay.updateWave(3);
        waveInProgress = true;
        
        if (player != null && player.getWorld() != null) {
            player.restoreFullHealth();
        }
        
        WaveCompleteMessage msg = new WaveCompleteMessage(3);
        addObject(msg, 400, 300);
        Greenfoot.delay(60);
        removeObject(msg);
        
        addObject(new Boss(), 400, 100);
        
        System.out.println("=== BOSS FIGHT STARTED ===");
    }

    private void spawnPowerUp() {
        if (gameEnded) return;
        int x = Greenfoot.getRandomNumber(700) + 50;
        int y = Greenfoot.getRandomNumber(500) + 50;
        addObject(new PowerUpHeart(), x, y);
    }

    public void enemyKilled() {
        enemiesKilled++;
    }

    public void addScore(int points) {
        if (gameEnded) return;
        score += points;
        scoreDisplay.updateScore(score);
    }

    public void updateHealth(int health) {
        if (gameEnded) return;
        healthDisplay.updateHealth(health);
    }

    public void updateAmmo(int ammo) {
        if (gameEnded) return;
        ammoDisplay.updateAmmo(ammo, player.getReloadTimer());
    }

    public void gameOver() {
        if (gameEnded) return;
        gameEnded = true;
        
        if (bgm != null) {
            bgm.stop();
            System.out.println("✓ Music stopped (Game Over)");
        }
        
        addObject(new GameOverScreen(), 400, 300);
        
        // ✅ JANGAN STOP GREENFOOT (biar retry button bisa diklik)
        // Greenfoot.stop(); // DIHAPUS
        
        System.out.println("✓ Game Over screen displayed");
    }

    public void playerWins() {
        if (gameEnded) return;
        gameEnded = true;
        
        if (bgm != null) {
            bgm.stop();
            System.out.println("✓ Music stopped (Victory)");
        }
        
        addObject(new WinScreen(), 400, 300);
        Greenfoot.stop();
    }

    public Player getPlayer() {
        return player;
    }
}